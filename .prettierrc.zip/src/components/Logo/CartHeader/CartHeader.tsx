type Props = {}
const CartHeader = (props: Props) => {
    return (
        <div>
            <div>0</div>
            <div>$0</div>
        </div>
    )
}
export default CartHeader
