import AutoList from 'components/Logo/AutoList/AutoList'

type Props = {}
const Home = (props: Props) => {
    return (
        <>
            <AutoList />
        </>
    )
}
export default Home
